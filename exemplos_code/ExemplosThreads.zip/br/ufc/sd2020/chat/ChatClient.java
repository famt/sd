package br.ufc.sd2020.chat;

import java.io.*;
import java.net.*;

public class ChatClient extends Thread {
	public static void main(String[] args) throws IOException {
		Socket echoSocket = null;
		PrintWriter out = null;
		BufferedReader br = null;
		try {
			echoSocket = new Socket("localhost", 7777);
			out = new PrintWriter(echoSocket.getOutputStream());
			br = new BufferedReader(new InputStreamReader(echoSocket
					.getInputStream()));
			Listen l = new Listen(br);
			l.start();
		} catch (UnknownHostException e) {
			System.err.println("Unknown host");
			System.exit(1);
		} catch (IOException e) {
			System.err.println("I/O Error");
			System.exit(1);
		}

		BufferedReader user_br = new BufferedReader(new InputStreamReader(
				System.in));
		String fromServer;
		String fromUser;
		
		while(true){
			fromUser = user_br.readLine();
			if (fromUser.equalsIgnoreCase("tchau"))
				break;
			out.println(fromUser);
			out.flush();

		}
		out.close();
		br.close();
		user_br.close();
		echoSocket.close();
	}
	
}

class Listen extends Thread{
	BufferedReader mensagens ;
	
	public Listen(BufferedReader mensagens) {
		this.mensagens = mensagens;
	}
	
	public void run(){
		String fromServer;
		try {
			while ((fromServer = mensagens.readLine()) != null) {
				System.out.println(fromServer);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
