package br.ufc.sd2020.chat;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class VisualClient extends javax.swing.JFrame {
	private JLabel jLabel1;
	private JScrollPane jScrollPane1;
	private JTextField mensagem;
	private JLabel jLabel2;
	private JPanel jPanel1;
	private JTextArea chat;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				VisualClient inst = new VisualClient();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public VisualClient() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			BorderLayout thisLayout = new BorderLayout();
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(thisLayout);
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1, BorderLayout.NORTH);
				jLabel1.setText("Mensagens Recebidas");
			}
			{
				jScrollPane1 = new JScrollPane();
				getContentPane().add(jScrollPane1, BorderLayout.CENTER);
				{
					chat = new JTextArea();
					jScrollPane1.setViewportView(chat);
				}
			}
			{
				jPanel1 = new JPanel();
				BorderLayout jPanel1Layout = new BorderLayout();
				jPanel1.setLayout(jPanel1Layout);
				getContentPane().add(jPanel1, BorderLayout.SOUTH);
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2, BorderLayout.NORTH);
					jLabel2.setText("Nova Mensagem:");
				}
				{
					mensagem = new JTextField();
					jPanel1.add(mensagem, BorderLayout.SOUTH);
/*					mensagem.addKeyListener(new KeyAdapter() {
						public void keyPressed(KeyEvent evt) {
							mensagemKeyPressed(evt);
						}
					});
*/					mensagem.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							mensagemActionPerformed(evt);
						}
					});
				}
			}
			pack();
			setSize(400, 300);
			inicializa();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private String participante;
	private String servidor;
	private int porta;
	PrintWriter writer = null;
	BufferedReader br;
	
	private void inicializa() throws UnknownHostException, IOException{
		participante = JOptionPane.showInputDialog("Digite seu nome","anonymous");
		 servidor = JOptionPane.showInputDialog("Digite o id do servidor","localhost");
		porta  =  Integer.parseInt(JOptionPane.showInputDialog("Digite a porta do servidor","7777"));
		criaSocket(servidor, porta);
	}

	private void criaSocket(String servidor2, int porta2) throws UnknownHostException, IOException {
		Socket echoSocket = new Socket(servidor2, porta);
		writer = new PrintWriter(echoSocket.getOutputStream());
		br = new BufferedReader(new InputStreamReader(echoSocket
				.getInputStream()));
		Listener l = new Listener(br, this);
		l.start();
	}

	public void writeMessage(String fromServer) {
		this.chat.append(fromServer+"\n");
		
	}
	
	private void mensagemActionPerformed(ActionEvent evt) {
		mandaMensagem();
	}
	
/*	private void mensagemKeyPressed(KeyEvent evt) {
		if (evt.getKeyCode() == KeyEvent.VK_ENTER){
			mandaMensagem();
		}
	}
*/
	private void mandaMensagem() {
		String m = this.mensagem.getText();
		writer.println("["+this.participante+"] "+ m);			
		writer.flush();
		writeMessage(m);
//		this.chat.append(m+"\n");
		this.mensagem.setText("");
	}

}

class Listener extends Thread{
	BufferedReader mensagens ;
	VisualClient visualClient ; 
	
	public Listener(BufferedReader mensagens, VisualClient visualClient) {
		this.mensagens = mensagens;
		this.visualClient= visualClient;
	}
	
	public void run(){
		String fromServer;
		try {
			while ((fromServer = mensagens.readLine()) != null) {
				visualClient.writeMessage(fromServer);
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

