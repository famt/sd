package br.ufc.sd2020.chat;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ChatServer {

	private ServerSocket server;
	private List<Socket> clientes = new ArrayList<Socket>();;

	public ChatServer(int porta) {
		initServer(porta);
	}

	private void initServer(int porta) {
		try {
			server = new ServerSocket(porta);
			while (true) {
				Socket cliente = server.accept();
				clientes.add(cliente);
				new ThreadClient(cliente, this).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendBroadCast(String linha, Socket cliente) {
		for (Socket c : clientes) {
			if (c != cliente) {

				try {
					PrintWriter out = new PrintWriter(c.getOutputStream(), true);
					out.println(linha);
					out.flush();
				} catch (IOException e) {
					disconnect(c);
				}
			}
		}
	}

	public static void main(String[] args) {
		new ChatServer(7777);
	}

	public void disconnect(Socket cliente) {
		System.out.println(cliente + "desconectado");
		clientes.remove(cliente);

	}
}
