package br.ufc.sd2020.chat;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.io.PrintWriter;
import java.net.Socket;

public class ThreadClient extends Thread {

	private Socket cliente;
	private ChatServer chatServer;
	private String nome;

	public ThreadClient(Socket cliente, ChatServer chatServer) {
		this.cliente = cliente;
		this.chatServer = chatServer;
		this.nome = "cliente";
	}

	
	public void run(){
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					cliente.getInputStream()));
			String linha = null;
			while ((linha = in.readLine()) != null) {
				this.chatServer.sendBroadCast(linha, cliente);
				System.out.println("mandei mensagem" +linha);
				if (linha.equalsIgnoreCase("tchau"))
					break;
			}
			in.close();
			cliente.close();
		} catch (IOException e) {
			chatServer.disconnect(cliente);
			e.printStackTrace();
		}
		
	}

}
