package br.ufc.sd2020;

public class Racer implements Runnable{

	private int i;
	
	public Racer(int i) {
		super();
		this.i = i;
	}

	public void imprimir() {
		System.out.println("Racer ("+ this.i+ ") imprimindo...");
	}
	
	public void run() {
		for (int x = 1; x < 5; x++) {
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			imprimir();
		}
	}

}
