package br.ufc.sd2020.prod_cons;

public class Mailbox {
	
	private boolean temMensagem = false;
	private String mensagem;
	
	private int totalMensagensProduzidas = 0;
	private int totalMensagensConsumidas = 0;
	
	
	public synchronized String get(int id)  {
		while (!temMensagem) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Consumidor #"+id+ " consumiu a mensagem ["+ mensagem + "]");
		System.out.println("Mensagens consumidas: "+ ++totalMensagensProduzidas);
		mensagem = "";
		temMensagem = false;
		notifyAll();
		return mensagem;
	}
	
	public synchronized void set(int id, String mensagem)  {
		while (temMensagem) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Produtor #"+id+ " criou a mensagem");
		System.out.println("Mensagens produzidas: "+ ++totalMensagensConsumidas);
		this.mensagem = mensagem;
		this.temMensagem = true;
		notifyAll();
	}
}
