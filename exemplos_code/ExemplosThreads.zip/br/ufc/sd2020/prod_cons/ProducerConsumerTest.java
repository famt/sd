package br.ufc.sd2020.prod_cons;

public class ProducerConsumerTest {
    public static void main(String[] args) {
        Mailbox mailbox = new Mailbox();
        Produtor p1 = new Produtor(1, mailbox);
        Consumidor c1 = new Consumidor(1, mailbox);
        Produtor p2 = new Produtor(2, mailbox);
        Consumidor c2 = new Consumidor(2, mailbox);

        new Thread(p1).start();
        new Thread(c1).start();
        new Thread(p2).start();
        new Thread(c2).start();

    }
}