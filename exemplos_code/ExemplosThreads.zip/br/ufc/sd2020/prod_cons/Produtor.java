package br.ufc.sd2020.prod_cons;

public class Produtor implements Runnable {
	
	private int id;
	private Mailbox mailbox;

	public Produtor(int id, Mailbox mailbox) {
		super();
		this.id = id;
		this.mailbox = mailbox;
	}

	public void run() {
        for (int i = 0; i < 10; i++) {
            String mensagem = "mensagem "+ (i+1) +" do produtor "+this.id;
            mailbox.set(this.id, mensagem );
            try {
                Thread.sleep((int)(Math.random() * 100));
            } catch (InterruptedException e) { }
        }
    

	}

}
