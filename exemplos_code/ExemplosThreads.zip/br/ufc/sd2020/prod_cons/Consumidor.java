package br.ufc.sd2020.prod_cons;

public class Consumidor implements Runnable {
	
	private int id;
	private Mailbox mailbox;

	public Consumidor(int id, Mailbox mailbox) {
		super();
		this.id = id;
		this.mailbox = mailbox;
	}

	public void run() {
        for (int i = 0; i < 10; i++) {
            String mensagem = mailbox.get(this.id);
            try {
                Thread.sleep((int)(Math.random() * 100));
            } catch (InterruptedException e) { }
        }
    

	}

}
