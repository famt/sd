package br.ufc.sd2020;

public class Race {
	
	public static void main(String[] args) {
		Thread t1 = new Thread(new Racer(1));
		Thread t2 = new Thread(new Racer(2));
		Thread t3 = new Thread(new Racer(3));
		Thread t4 = new Thread(new Racer(4));
		Thread t5 = new Thread(new Racer(5));
		Thread t6 = new Thread(new Racer(6));
		Thread t7 = new Thread(new Racer(7));
		Thread t8 = new Thread(new Racer(8));
		Thread t9 = new Thread(new Racer(9));
		Thread t10 = new Thread(new Racer(10));
		t1.start();
		t3.start();
		t5.start();
		t7.start();
		t9.start();
		try {
			t1.join();
			t3.join();
			t5.join();
			t7.join();
			t9.join();			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		t2.start();
		t4.start();
		t6.start();
		t8.start();
		t10.start();
	}

}
