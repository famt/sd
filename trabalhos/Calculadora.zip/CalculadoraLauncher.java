import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CalculadoraLauncher {
	 public  static void main(String args[]) throws RemoteException, MalformedURLException{
	     Calculadora calc =  new Calculadora();
	     Registry reg = null;
	     try {
	    	 reg = LocateRegistry.createRegistry(1099);	 
	     } catch (Exception e) {
	    	 reg = LocateRegistry.getRegistry(1099);
	     }
	     System.out.println("Servidor no ar...");
	     reg.rebind("servidorF30",calc);	     
	}
}
