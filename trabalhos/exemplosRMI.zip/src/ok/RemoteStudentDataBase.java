package ok;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.Naming;

import java.util.Map;
import java.util.Hashtable;


public class RemoteStudentDataBase extends UnicastRemoteObject implements StudentDataBase {

  public Map cache;

  public RemoteStudentDataBase() throws RemoteException {
    super();
    cache = new Hashtable();
  }

  public void putStudent(Student student) throws RemoteException {
    cache.put(student.getLogin(), student);
    System.out.println("Student "+student.getName()+" saved");
  }
  public Student getStudent(String login) throws RemoteException {
    Student s = (Student) cache.get(login);
    System.out.println(" Retrievind Student "+s.getName());
    return s;
  }

  public static void main(String[] args) throws RemoteException {
	StudentDataBase db = new RemoteStudentDataBase();
	Registry reg = null;
	try {
	    reg = LocateRegistry.createRegistry(1099);	 
	} catch (Exception e) {
	    reg = LocateRegistry.getRegistry(1099);
	}
	System.out.println("Servidor no ar...");
    reg.rebind("studentDB",db);	     
  }


}