package ok;
import java.rmi.AccessException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

class StudentClientGetting {
  public static void main(String[] args) throws RemoteException {
		Registry reg = null;
		try {
			 reg = LocateRegistry.createRegistry(1099);	 
		} catch (Exception e) {
			 try {
				reg = LocateRegistry.getRegistry(1099);
			} catch (RemoteException e1) {
				// TODO Auto-generated catch block
				System.exit(0);
			}
		}
		StudentDataBase database;
		try {
			database = (StudentDataBase) reg.lookup("studentDB");
	        Student s = database.getStudent("famt");
	        System.out.println(s);
	        System.out.println(s.getPassword());
		} catch (AccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }

}
