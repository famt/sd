package ok;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

class StudentClientInserting {
  public static void main(String[] args) throws RemoteException, NotBoundException {
	Registry reg = null;
	try {
		 reg = LocateRegistry.createRegistry(1099);	 
	} catch (Exception e) {
		 try {
			reg = LocateRegistry.getRegistry(1099);
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			System.exit(0);
		}
	}
	StudentDataBase database = (StudentDataBase) reg.lookup("studentDB");
    Student s = new Student("Fernando", "famt", "senha");
    database.putStudent(s);
    Student s1 = new Student("Carlos", "cagf", "XXX");
    database.putStudent(s1);
    Student s2 = new Student("Ian", "ibt", "nai");
    database.putStudent(s2);	
  }
}