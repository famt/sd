package ok;

import java.io.Serializable;

public class Student implements Serializable {

  public static int QUANT = 0;

  private String name;
  private String login;
  private transient String password;
  private int code;

  public Student(){

  }

  public Student(String _name, String _login, String _password){
    this.code = Student.QUANT++;
    this.name = _name;
    this.login = _login;
    this.password = _password;
  }

  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public String getLogin() {
    return login;
  }
  public void setLogin(String login) {
    this.login = login;
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public int getCode() {
    return code;
  }
  public void setCode(int code) {
    this.code = code;
  }

  public String toString(){
    return "Student "+ this.name+", login:"+this.login+", code:"+this.code;
  }

}