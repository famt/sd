package ok;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface StudentDataBase extends Remote {

  public void putStudent(Student student) throws RemoteException;

  public Student getStudent(String login) throws RemoteException;


}