import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ClienteCalculadora {
	
	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {
	     Registry reg = LocateRegistry.getRegistry(1099);
	    ICalculadora calc = (ICalculadora) reg.lookup("servidorF30");
		System.out.println(calc.soma(5,6));
	}

}
