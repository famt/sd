import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Calculadora extends UnicastRemoteObject implements ICalculadora{

	int numVezes = 0;
	
	protected Calculadora() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	private static final long serialVersionUID = 1L;

	@Override
	public int soma(int a, int b) throws RemoteException {
		System.out.println("Método soma foi chamado " + ++numVezes + " vezes");
		return a + b;
	}

}
